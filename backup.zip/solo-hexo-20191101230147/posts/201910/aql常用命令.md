title: aql常用命令
date: '2019-10-29 21:11:33'
updated: '2019-10-29 21:13:25'
tags: [Aerospike]
permalink: /articles/2019/10/29/1572354693549.html
---
![](https://img.hacpai.com/bing/20180701.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1， 查询某个namespace下面set
SELECT * FROM riskaero1-storage1.G2_IP

## 2， 泛化查询
show namespaces
show sets
show bins
show modules

## 3, 精确查询
SELECT * FROM riskaero1-storage1.G2_IP where PK=30103034967203863;

## 4, stats
stat system
STAT NAMESPACE riskaero1-storage1;
