title: PowerMock入门
date: '2019-11-17 22:24:44'
updated: '2019-11-17 22:37:06'
tags: [测试, PowerMock]
permalink: /articles/2019/11/17/1574000684581.html
---
在项目的测试代码中，有一段测试是测试一段网络程序的代码。经常因为网络不稳定，返回不同的结果，而造成整个项目测试的行覆盖率和分支覆盖率的变化。因为commit的提交。
最后实在受不了了，用powermock把网络爬取数据的一段在测试的时候用mock实现了。这样有两个好处：
1. 摆脱了对网络的依赖，无论几次运行，测试的覆盖率是稳定的。
2. 不需要真正的访问网络，加快了测试的运行速度。

## 1. Pom依赖
在Junit使用powermock首先要在pom里面引入依赖。因为junit和powermock版本需要一直（曾经找过几个博客发现讲的很好，但是就是不work，后来发现是这两个jar的版本不match）。这里贴出一组肯定work的版本。
```
<dependency>
   <groupId>junit</groupId>
   <artifactId>junit</artifactId>
   <version>4.12</version>
   <scope>test</scope>
</dependency>
<dependency>
   <groupId>org.powermock</groupId>
   <artifactId>powermock-module-junit4</artifactId>
   <version>1.6.4</version>
   <scope>test</scope>
</dependency>
<dependency>
   <groupId>org.powermock</groupId>
   <artifactId>powermock-api-mockito</artifactId>
   <version>1.6.4</version>
   <scope>test</scope>
</dependency>
```

## 2. 测试类添加注解
这里一个主要的注解是用 PowerMockRunner 来运行测试。另外一个参数 fullyQualifiedNames是配置你要mock的类路径。
```  
@RunWith(PowerMockRunner.class)  
@PrepareForTest(fullyQualifiedNames = "com.example.package.*")  
```

## 3. 不同的mock场景
### 3.1 Mock static public method
```
PowerMockito.mockStatic(ExampleClass.class);                           
when(ExampleClass.exampleStaticMethod(Mockito.any())).thenReturn(null);
```
### 3.2 Mock static private method
```
PowerMockito.spy(ExampleClass.class);
PowerMockito.doReturn(null).when(ExampleClass.class, "privateMethod", Mockito.any());
```
当然public方法也可以用这种方式来mock。

### 3.3 mock public non-static method
测试类注解参照上面，代码里面修改示例：
```
App app = new App();
MyDAO mockDao = Mockito.mock(MyDAO.class);
Student mockStudent = Mockito.mock(Student.class);
PowerMockito.whenNew(MyDAO.class).withNoArguments().thenReturn(mockDao);
Mockito.when(mockDao.getStudentDetails()).thenReturn(mockStudent);
Mockito.when(mockStudent.getName()).thenReturn("mock");
assertEquals("mock", app.getStudent().getName());
```

### 3.4 mock method throw exception
测试类注解参照上面，代码里面修改示例：
```
PowerMockito.doThrow(new IOException("Network Error")).when(ExampleClass.class, "exampleMethod", Mockito.any(), Mockito.any());
```
